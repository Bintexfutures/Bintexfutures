<!-- START SECTION EXCHANGE -->
<section class="small_pt small_pb section_gradiant" style="background-image: url(assets/images/exchange-bg-image.png); height:auto;" class="img-fluid" >
    <div class="container">
        <div class="row align-items-center">
            <div class="offset-lg-2 col-lg-8 offset-md-2 col-md-8 col-sm-12">				
				<div class="title_default_light text-center">
                <h4 class="animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.2s" style="animation-delay: 0.2s; opacity: 1;"></h4>
                <h4 class="animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.4s" style="animation-delay: 0.4s; opacity: 1;">NON-CUSTODIAL Futures Exchange</h4>
              </div>
				<div class="text-center">
                	<img class="animation" data-animation="zoomIn" data-animation-delay="0.2s" src="assets/images/laptop.png" alt=""/> 
                </div>                
            </div>
        </div>
    </div>
</section>
<!-- END SECTION EXCHANGE -->

<!-- SECTION MOBILE APP -->
<div class="bg-color small_pt small_pb">
	<div class="container">
    	<div class="row align-items-center">
            <div class="col-lg-9 col-md-12 col-sm-12">
              <div class="title_default_light title_border text_md_center">
                  
                  
                <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Download Mobile App</h4>
                <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"> Traders submit buy and sell orders instantly with a single click.
An intuive ladder trading interface displays live bids and offers
moving up and down on a central price column. Traders get and
stay in the zone when there’s no need to move the mouse or use
the keyboard or look away from the price acon to place trades.</p>
<h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Trade. Anywhere.</h4>

<p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s">
All the power of BintexFutures exchange,
in the palm of your hand.
Download the BINTEX mobile crypto trading app soon. </p>

<!--<a class="btn btn-default btn-radius animation animated fadeInUp" target="_blank" href="https://play.google.com/store" data-animation="fadeInUp" data-animation-delay="1s" style="animation-delay: 1s; opacity: 1; width:21%; text-transform: none;"><i class="fa fa-android icon" style="    padding: 18px 155px 0 0;"></i><em>Download now for</em> Android</a>
<a class="btn btn-default btn-radius animation animated fadeInUp" target="_blank" href="https://www.apple.com/ios/app-store/" data-animation="fadeInUp" data-animation-delay="1s" style="animation-delay: 1s; opacity: 1;  width:21%; text-transform: none;"><i class="fa fa-apple icon" style="    padding: 18px 155px 0 0;"></i><em>Download now for</em> iPhone</a> --->
              </div>
            </div>
            <div class="col-lg-3 col-md-12 col-sm-12">
                <div class="res_md_mt_50 res_sm_mt_20 text_md_center animation" data-animation="fadeInRight" data-animation-delay="0.2s"> 
                    <img src="assets/images/phone.png" alt="mobile_app2"/> 
                </div>
            </div>
       </div>
    </div>
</div>
<!-- END SECTION MOBILE APP -->



    <link href="<?php echo base_url() ?>css/timeTo.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="node_modules/jquery/dist/jquery.min.js"><\/script>')</script>
    <script src="<?php echo base_url() ?>css/jquery.time-to.js"></script>