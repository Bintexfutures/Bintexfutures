<!-- START SECTION TOKEN SALE -->
<section class="v_blue small_pt small_pb">
	<div class="container"> 
	
	
	 <?php $i=1; $a=$this->db->get_where('logo')->row();  ?>  
<script>
// Set the date we're counting down to
var countDownDate = new Date("23 January 2020 9:56:00 GMT+01:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + " : " + hours + " : "
  + minutes + " : " + seconds + "";
  document.getElementById("demo2").innerHTML = days + " : " + hours + " : "
  + minutes + " : " + seconds + "";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>

<?php $sans=$this->db->get_where('thenumber', array('id' => '2' ))->row(); ?>

		<div class="row">
			<div class="col-lg-6 offset-lg-3 col-md-12 col-sm-12">
                <div class="title_default_light title_border text-center">
                    <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s"><?php echo $sans->name; ?></h4>
                    <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $sans->description; ?></p>
                </div>
			</div>
        </div>
        <div class="row align-items-center">
        	<div class="col-lg-3">
            	<div class="pr_box">
                      <h6 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Starting time :</h6>
                      <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $sans->pinterest; ?></p>
                    </div>
                <div class="pr_box">
                  <h6 class="animation" data-animation="fadeInUp" data-animation-delay="0.6s">Ending time :</h6>
                  <p class="animation" data-animation="fadeInUp" data-animation-delay="0.8s"><?php echo $sans->number1; ?></p>
                </div>
                <div class="pr_box">
                      <h6 class="animation" data-animation="fadeInUp" data-animation-delay="1s">Tokens exchange rate</h6>
                      <p  class="animation" data-animation="fadeInUp" data-animation-delay="1.2s"><?php echo $sans->number2; ?></p>
                    </div>
            </div>
            
<?php $san=$this->db->get_where('thenumber', array('id' => '1' ))->row(); ?>
            <div class="col-lg-6">
            	<div class="token_sale res_md_mb_40 res_md_mt_40 res_sm_mb_30 res_sm_mt_30">
                    <div class="tk_countdown text-center animation token_countdown_bg" data-animation="fadeIn" data-animation-delay="1s">
                        <div class="tk_counter_inner">
                          
                          <div class="tk_countdown_time border-0 animation animated fadeInUp">
 <div class="text-center fgju" style="font-size: 43px;
    font-weight: 600;     padding: 10px; color: #a3ce7a;" id="demo"> </div>
    <div> 
    <span style="font-size: 12px; font-weight: 600; padding: 10px 0px 10px 10px; color: #a3ce7a;">DAYS</span>
    <span style="font-size: 12px; font-weight: 600; padding: 10px 10px 10px 30px; color: #a3ce7a;">HOURS</span>
    <span style="font-size: 12px; font-weight: 600; padding: 10px; color: #a3ce7a;">MINUTES</span>
    <span style="font-size: 12px; font-weight: 600; padding: 10px; color: #a3ce7a;">SECONDS</span>
    </div>
 </div>
 
                            <div class="progress animation" data-animation="fadeInUp" data-animation-delay="1.3s">
                            <div class="progress-bar progress-bar-striped gradient" role="progressbar" aria-valuenow="46" aria-valuemin="0" aria-valuemax="100" style="width:46%"> 46% </div>
                                <span class="progress_label bg-white" style="left: 25%"> <strong> <?php echo $san->number1; ?> </strong></span>
                                <span class="progress_label bg-white" style="left: 75%"> <strong> <?php echo $san->number2; ?> </strong></span>
                                <span class="progress_min_val">Sale Raised</span>
                                <span class="progress_max_val">Soft-caps</span>
                            </div>
                        	<a href="<?php echo base_url();?>login" target="_blank" class="btn btn-default btn-radius animation" data-animation="fadeInUp" data-animation-delay="1.4s">Buy Tokens </a>
                            <ul class="icon_list list_none d-flex justify-content-center">
                            	<li class="animation" data-animation="fadeInUp" data-animation-delay="1.5s"><img src="assets/images/payment_icons.png" alt=""></li>
                            </ul>                        
                        </div>
                	</div>
                </div>  
            </div>
            <div class="col-lg-3">
            	<div class="pr_box">
                        <h6 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Low - High 24h :</h6>
                        <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $sans->designation; ?></p>
                    </div>
                <div class="pr_box">
                  <h6 class="animation" data-animation="fadeInUp" data-animation-delay="0.6s">Total tokens sale</h6>
                  <p class="animation" data-animation="fadeInUp" data-animation-delay="0.8s"><?php echo $sans->facebook; ?></p>
                </div>
                <div class="pr_box">
                        <h6 class="animation" data-animation="fadeInUp" data-animation-delay="1s">Acceptable Currency :</h6>
                        <p class="animation" data-animation="fadeInUp" data-animation-delay="1.2s"><?php echo $sans->twitter; ?></p>
                    </div>
            </div>
        </div>
    </div>
</section>
<!-- END SECTION TOKEN SALE --> 

<!-- START SECTION TOKEN PROCEEDS & DISTRIBUTION -->
<section class="v_blue small_pt small_pb">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 offset-lg-3 col-md-12 col-sm-12">
                <div class="title_default_light title_border text-center">
                    <?php $data1=$this->db->get_where('aboutus', array('id' => '4' ))->row(); ?>



                    <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Token Sale Proceeds</h4>
                    <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $data1->heading ?></p>
                </div>
			</div>
        </div>    
        <div class="row align-items-center">
          <div class="col-lg-7 col-md-7">
            <div class="lg_pt_20 res_sm_pt_0 res_sm_mb_20 text-center animation" data-animation="fadeInRight" data-animation-delay="0.2s"> 
            	<img  src="<?php echo base_url() ?>admin/assets/aboutpage/<?php echo $data1->image ?>" alt="sale-proceeds4" /> 
            </div>
          </div>
          <div class="col-lg-4 offset-lg-1 col-md-5">
            <ul class="list_none chart_list_info animation" data-animation="fadeInLeft" data-animation-delay="0.2s">
            <?php echo $data1->content ?>
            </ul>
          </div>
        </div>
        <div class="divider large_divider"></div>
        <div class="row">
          <div class="col-lg-6 offset-lg-3 col-md-12 col-sm-12">
			<div class="title_default_light title_border text-center">
			    
			     <?php $data1=$this->db->get_where('aboutus', array('id' => '5' ))->row(); ?>
                <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Token Distribution</h4>
                <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $data1->heading ?></p>
            </div>
          </div>
        </div>
        <div class="row align-items-center">
          <div class="col-lg-4 col-md-5">
            <ul class="list_none chart_list_info animation" data-animation="fadeInRight" data-animation-delay="0.2s">
            	<?php echo $data1->content ?>
            </ul>
          </div>
          <div class="col-lg-7 offset-lg-1 col-md-7">
            <div class="lg_pt_20 res_sm_pt_0 res_sm_mt_20 text-center animation" data-animation="fadeInLeft" data-animation-delay="0.2s"> 
            	<img  src="<?php echo base_url() ?>admin/assets/aboutpage/<?php echo $data1->image ?>" alt="distribution4" /> 
            </div>
          </div>
        </div>
  </div>
</section>
<!-- END SECTION TOKEN PROCEEDS & DISTRIBUTION -->

 <link href="<?php echo base_url() ?>css/timeTo.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="node_modules/jquery/dist/jquery.min.js"><\/script>')</script>
    <script src="<?php echo base_url() ?>css/jquery.time-to.js"></script>
    <script>
        $('#clock-w-step-cb').timeTo({
          step: function() {
              console.log('Executing every 3 ticks');
          },
          stepCount: 3
        });

        var date = getRelativeDate(2);
        document.getElementById('date-str').innerHTML = date.toISOString();        /**
         * Set timer countdown to specyfied date
         */
        $('#countdown-2').timeTo(date);
        
        var time = '<?php echo $a->eventdate ; ?>';
        document.getElementById('date2-str').innerHTML = time;
        $('#countdown-3').timeTo({
            time: time,
            displayDays: 2,
            theme: "black",
            displayCaptions: true,
            fontSize: 38,
            captionSize: 14,
            lang: 'en'
        });
        $('#clock-1').timeTo();
        function getRelativeDate(days, hours, minutes) {
            var d = new Date(Date.now() + 60000 /* milisec */ * 60 /* minutes */ * 24 /* hours */ * days /* days */);
            d.setHours(hours || 0);
            d.setMinutes(minutes || 0);
            d.setSeconds(0);
            return d;
        }
    </script>