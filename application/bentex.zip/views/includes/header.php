<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="" />
<meta name="author" content="mgr" />
<title>BINTEX FUTURES</title>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.png">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.css" >
<link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" >
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ionicons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/owlcarousel/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/owlcarousel/css/owl.theme.default.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/magnific-popup.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/spop.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">
<link id="layoutstyle" rel="stylesheet" href="<?php echo base_url();?>assets/color/theme.css">
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>
<body class="bg-color" data-spy="scroll" data-offset="110">
<!--<div id="loader-wrapper">
    <div id="loading-center-absolute">
        <div class="object" id="object_four"></div>
        <div class="object" id="object_three"></div>
        <div class="object" id="object_two"></div>
        <div class="object" id="object_one"></div>
    </div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div> -->
<header class="header_wrap fixed-top">
	<div class="container-fluid">
		<nav class="navbar navbar-expand-lg"> 
			<a class="navbar-brand page-scroll animation" href="<?php echo base_url();?>" data-animation="fadeInDown" data-animation-delay="1s"> 
            	

<?php $i=1; $a=$this->db->get_where('logo')->row();  ?>                 
   <img class="logo_light" src="<?php echo base_url();?>admin/assets/aboutpage/<?php echo @$a->image; ?>" alt="logo" /> 
                <img class="logo_dark" src="<?php echo base_url();?>admin/assets/aboutpage/<?php echo @$a->image; ?>" alt="logo" /> 
<?php  ?>


            </a>
            <button class="navbar-toggler animation" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" data-animation="fadeInDown" data-animation-delay="1.1s"> 
                <span class="ion-android-menu"></span> 
            </button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">

    <?php 
$current =  $this->uri->segment(1); 
$current_1 =  $this->uri->segment(2); 

?>


<ul class="navbar-nav m-auto">   
<li class="animation  <?php if($current == 'home' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.1s">
<a class="nav-link page-scroll nav_item" href="<?php echo base_url();?>">Home</a></li>
<li class="animation  <?php if($current == 'exchange' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.1s">
<a class="nav-link page-scroll nav_item" href="<?php echo site_url('');?>exchange">Exchange</a></li>
<li class="animation" <?php if($current == 'bintex' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.2s">
<a class="nav-link page-scroll nav_item" href="<?php echo site_url('');?>bintex">BNTX</a></li>
<li class="animation" <?php if($current == 'token' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.3s">
<a class="nav-link page-scroll nav_item" href="<?php echo site_url('');?>token">Token</a></li>
<li class="animation" <?php if($current == 'roadmap' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.4s">
<a class="nav-link page-scroll nav_item" href="<?php echo site_url('');?>roadmap">Road Map</a></li>
<li class="animation" <?php if($current == 'team' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.5s">
<a class="nav-link page-scroll nav_item" href="<?php echo site_url('');?>team">Team</a></li>
<li class="animation" <?php if($current == 'news' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.6s">
<a class="nav-link page-scroll nav_item" href="<?php echo site_url('');?>news">News</a></li>
<li class="animation" <?php if($current == 'faq' || $current == ''  ){ echo "active"; }  ?>" data-animation="fadeInDown" data-animation-delay="1.7s">
<a class="nav-link page-scroll nav_item" href="<?php echo site_url('');?>faq">FAQS</a></li>
<li class="animation dropdown" data-animation="fadeInDown" data-animation-delay="1.8s">
<a href="#" class="nav-link nav_item dropdown-toggle" data-toggle="dropdown">More <span class="caret"></span></a>				
						  <ul class="dropdown-menu" role="menu">
			<li><a href="<?php echo site_url('');?>aboutus">About Us</a></li>
							<li><a href="<?php echo site_url('');?>getsupport">Get Support</a></li>
							<li><a href="<?php echo site_url('');?>contact">Contact Us</a></li>
						  </ul> 
					</li>
                </ul>
                <ul class="navbar-nav nav_btn align-items-center">                   
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="2s"><a class="btn btn-default btn-radius nav_item" target="_blank" href="<?php echo base_url() ?>">Buy BNTX Tokens</a></li>
					<li class="animation" data-animation="fadeInDown" data-animation-delay="2s">
					    <a class="nav_item" target="_blank" href="<?php echo base_url();?>login">Login</a> 
					<!--<a class="nav_item"  href="#<?php echo base_url();?>register">Register</a></li>	--> 				
					<li class="animation" data-animation="fadeInDown" data-animation-delay="1.9s">
                        <div class="lng_dropdown">
						<select name="countries" id="lng_select">
						    <option value='en' data-image="assets/images/en.png" data-title="English">EN</option>
                        </select>
                        </div>
                   </li>
                </ul> 
			</div>
		</nav>
	</div>
</header>
<!-- END HEADER --> 