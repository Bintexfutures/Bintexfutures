<!--
<div style="padding:50px;">
 <h1>Friendly Matrimony</h1>
   <a href="<?php echo base_url('register/resetpassword?link='.$link); ?>"> Click here to reset your password</a>
<br>

   <div 
   style="font-size: 26px;
   font-weight: 700;
   letter-spacing: -0.02em;
   line-height: 32px;
   color: #41637e;
   font-family: sans-serif;
   text-align: center" align="center" id="emb-email-header">
       <img style="border: 0;-ms-interpolation-mode: bicubic;
                 display: block;
                 Margin-left: auto;
                 Margin-right: auto;
                 max-width: 152px" src="<?php echo base_url(); ?>/assets/images/logo-new.png" alt="" width="152" height="108"></div>
  
<div> -->

<table style="max-width:699px;
             width:100%;
             font-family:Arial,Helvetica,sans-serif;
             background:#f4f3f4" cellspacing="0" cellpadding="20" border="0" align="center">

 <tbody> 
 <tr> 
 <td> 
  <div style="border-radius:8px;
              background:#fff;
              border:solid 1px #bfbfbf;
              overflow:hidden"> 


<table class="m_852120989219799036fullWidth" cellspacing="0" cellpadding="0" border="0"> 
    <tbody> 
       <tr> 
          <td style="padding:10px 15px" bgcolor="#FFFFFF" align="center"> 

<table class="m_852120989219799036halfWidth" width="220" cellspacing="0" cellpadding="0" border="0" align="left">
   <tbody> 
     <tr> 
       <td> 
         <img src="" class="CToWUd" width="100%">
      </td> 
     </tr> 
    </tbody> 
</table>  
    </td> 
    </tr> 
   
    <tr> 
      <td align="center"> 
        <img src="https://bintexfutures.com/images/dashboard_logo.png" class="CToWUd" style="width:100% height:auto">
      </td> 
    </tr> 
    
   <tr> 
     <td style="font-family:Arial,Helvetica,sans-serif;font-size:12px;
               padding:15px;
               padding-top:10px;
               color:#4c4c4c"> 
  <div style="background:#f4f3f4;border-radius:5px;padding:15px;border:solid 1px #bfbfbf;">  	
<span style="font-size:22px;">Reset your password?</span> <br /><br />

We are pleased to inform that the password for your bintexfutures.com account has been Reset as per click the button below. 
If you didn't make this request, ignore this email.

 <br> 
 <br> 
<?php @$santhosh='ei'.rand('0','106660').'crgtert'.rand('0','2000');
   @$santhosh1='ferr'.rand('0','55100').'yhrtyc'.rand('0','2000');
   @$santhosh2='jkllk'.rand('0','1700').'ikluic'.rand('0','2000');
   @$santhosh3='rret'.rand('0','1700').'asdc'.rand('0','2000');
   @$santhosh4='tyutyut'.rand('0','16600').'fhtyrt'.rand('0','2000');
   @$santhosh5='sdfsdf'.rand('0','16600').'sefdvc'.rand('0','2000');
   @$santhosh6='sdfsdf'.rand('0','16600').'ghjgft'.rand('0','2000');
   @$santhosh7='sdf'.rand('0','1060').'cdfrf'.rand('0','2000');
   @$santhosh8='esdi'.rand('0','10660').'cdfswer'.rand('0','2000'); ?>

 <a href="<?php echo base_url('') ?>register/resetpassword/<?php echo $santhosh ?>/<?php echo $santhosh1 ?>/<?php echo $link ?>/<?php echo $santhosh3 ?>/<?php echo $santhosh4 ?>/<?php echo $santhosh5 ?>" style="color:#fff;
           border-radius:5px;
           background:#097B00;
           padding:10px 15px;
           display:block;
           width:225px;
           font-family:Arial,Helvetica,sans-serif;font-size:14px;
           text-decoration:none" >Click here to reset your password</a> </div> </td> </tr> 

 <tr></tr>  </tbody> </table> 
 <table class="m_852120989219799036fullwidth" width="100%" cellspacing="0" cellpadding="0" border="0"> <tbody> <tr> <td bgcolor="#097B00"> 
 <table class="m_852120989219799036fullWidth" width="100%" height="51" cellspacing="0" cellpadding="0" border="0" align="left"> <tbody> 
 <tr> <td width="100%" style="text-align: center; color: #fff; font-size: 14px"> Wish you a successful partner search. <br> Team bintexfutures.com </td> </tr> 
 </tbody> </table>  
 </td> </tr> </tbody> </table> </div> </td> </tr> </tbody> 
 </table>









