<!-- START FOOTER SECTION -->
<footer>
	<div class="footer_top" data-z-index="1" data-parallax="scroll">
		<div class="container">
		    <div class="row">
				
			<div class="col-lg-12 col-md-12">
            	<div class="contact_box_s2 animation animated fadeInLeft" data-animation="fadeInLeft" data-animation-delay="0.1s" style="animation-delay: 0.1s; opacity: 1;">
                    <div class="contact_title text-center">
                        <i class="fa fa-send fa-2x" aria-hidden="true"></i>
						<h5 class="animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.2s" style="animation-delay: 0.2s; opacity: 1;">Official Bintex telegram</h5>
						<ul class="list_none contact_info mt-margin">
                        <li class="animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.4s" style="animation-delay: 0.4s; opacity: 1; padding-right: 15px;"> 
                        	Bintex Chat: <a href="https://t.me/bintexfutures_chat" target="_blank">chatlink</a>
                        </li>
                    </ul>
                    </div>
                </div>  
	</div>
				
			</div>
			</div>
			</div>
	 <div class="top_footer" data-z-index="1" data-parallax="scroll">
		<div class="container">
			<div class="row">
				
				<div class="col-lg-4 col-md-6 res_md_mt_30 res_sm_mt_20">
                	<h4 class="footer_title border_title animation" data-animation="fadeInUp" data-animation-delay="0.2s">Community</h4>
        
        
       <!-- <style>
        .list_arrow li i{ float: left; }
        </style>-->
        <ul class="footer_link list_arrow">


<?php $san=$this->db->get_where('socialmedia', array('id' => '1' ))->row(); ?>
 <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><a target="_blank" href="<?php echo $san->link; ?>">
     <span><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</span></a></li>   
   


<?php $san=$this->db->get_where('socialmedia', array('id' => '2' ))->row(); ?>
 <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><a target="_blank" href="<?php echo $san->link; ?>">
     <span><i class="fa fa-twitter" aria-hidden="true"></i> Twitter</span></a></li> 
     
     

<?php $san=$this->db->get_where('socialmedia', array('id' => '3' ))->row(); ?>
 <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><a target="_blank" href="<?php echo $san->link; ?>">
     <span><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</span></a></li> 
     
     

<?php $san=$this->db->get_where('socialmedia', array('id' => '4' ))->row(); ?>
 <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><a target="_blank" href="<?php echo $san->link; ?>">
     <span><i class="fa fa-telegram" aria-hidden="true"></i> Telegram</span></a></li>      
     
  


<?php $san=$this->db->get_where('socialmedia', array('id' => '5' ))->row(); ?>
 <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><a target="_blank" href="<?php echo $san->link; ?>">
     <span><i class="fa fa-youtube-play" aria-hidden="true"></i> Youtube</span></a></li> 
     

		</ul>
                </div>
				
				<div class="col-lg-3 col-md-6 res_md_mt_30 res_sm_mt_20">
                	<h4 class="footer_title border_title animation" data-animation="fadeInUp" data-animation-delay="0.2s">Legal</h4>

<ul class="footer_link list_arrow">
<?php $data1=$this->db->get_where('privacy', array('id'=>5))->row(); ?>					
    <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s">
        <a href="<?php echo base_url();?>admin/assets/aboutpage/<?php echo $data1->image ?>" target="_blank">Terms Of Use</a></li>
<?php $data1=$this->db->get_where('privacy', array('id'=>6))->row(); ?>
    <li class="animation" data-animation="fadeInUp" data-animation-delay="0.5s">
        <a href="<?php echo base_url();?>admin/assets/aboutpage/<?php echo $data1->image ?>" target="_blank">Privacy Policy</a></li>


</ul>
                </div> 
				<div class="col-lg-5 col-md-12">
                    <div class="footer_logo mb-3 animation" data-animation="fadeInUp" data-animation-delay="0.2s"> 
                        <!--<a href="#home_section" class="page-scroll">
                            <img alt="logo" src="<?php echo base_url();?>assets/images/dashboard_logo.png">
                        </a> --><div class="newsletter_form text-center" style="background: unset; padding: unset;">
                        <h2 class="border_title animation" data-animation="fadeInUp" data-animation-delay="0.2s" style="    color: #68E3FC; font-weight: 600; float: left;">Subscribe to our Mailing List</h2>
                        <!--<p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s">We'll send you updates about Bintex</p> -->
                        
    <?php 

   if(isset($_POST['subscribe']))
   {
     extract($_POST);
     $dt=$this->db->get_where('subscribe', array( 'email'=>$email));
     if ($dt->num_rows() > 0) {
       echo '<script>
       swal({
          title: "Email Already Exits",
          icon: "error",
          button: "Ok",
        });
       </script>';
     }  
   
    
     else {
       extract($_POST);
      // print_r($_POST);
       $data = array(
       'email'=>$email);
       $res=$this->db->insert('subscribe', $data);
       
       


       if($res){
         echo '<script>
         swal({
            title: "Thank you for Your Subscription.!",
            icon: "success",
            button: "Ok",
          });
         </script>';
         
     }
   }
   }
	?>
                        
                        <form class="subscribe_form animation" method="POST" data-animation="fadeInUp" data-animation-delay="0.4s">
                            <input class="input-rounded" type="text" name="email" required placeholder="Enter Email Address"/>
                          <button type="submit" title="Subscribe" class="btn-info" name="subscribe" value="Submit" style="     background-image: linear-gradient(#1990FF, #1CD0FF);"> Subscribe </button>
                        </form>
                    </div>
                 </div>                    
         		</div>
      		</div>
      		<div class="col-md-12">
          <p class="copyright" style="float: right;"> © 2019 Bintexfutures.com All rights reserved</p>
        </div>
    	</div>
    </div>
   <!--<div class="bottom_footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        </div>
        <div class="col-md-6">
          <ul class="list_none footer_menu">
            <li><a href="#contact">Contact Us</a></li>
          </ul>
        </div><p class="copyright" style="float: right;">Copyright &copy; Bintexfutures 2019 All Rights Reserved.</p>
      </div> 
    </div>
    </div>-->
</footer>
<!-- END FOOTER SECTION --> 

<script src="<?php echo base_url();?>assets/js/jquery-1.12.4.min.js"></script> 
<script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url();?>assets/owlcarousel/js/owl.carousel.min.js"></script> 
<script src="<?php echo base_url();?>assets/js/magnific-popup.min.js"></script>
<script src="<?php echo base_url();?>assets/js/waypoints.min.js"></script>
<script src="<?php echo base_url();?>assets/js/parallax.js"></script> 
<!--<script src="<?php echo base_url();?>assets/js/jquery.countdown.min.js"></script> -->
<script src="<?php echo base_url();?>assets/js/particles.min.js"></script> 
<script src="<?php echo base_url();?>assets/js/jquery.dd.min.js"></script> 
<!--<script src="<?php echo base_url();?>assets/js/jquery.counterup.min.js"></script> -->
<script src="<?php echo base_url();?>assets/js/spop.min.js"></script> 
<!--<script src="<?php echo base_url();?>assets/js/notification.js"></script> -->
<script src="<?php echo base_url();?>assets/js/scripts.js"></script>
</body>
</html>