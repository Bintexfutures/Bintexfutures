
<!---<h1> Sucessfull verified</h1>
<a href="https://bintexfutures.com/login">Go to Login </a>-->
        <!---<div class="col-md-6 col-sm-6 offset-md-3" style="width: 50%; text-align: center;">
            	<div style='background-color:#eeefef; padding:15px 20px;'>
            	     <div class='col-md-12'>
                        <div style='margin:0 auto; text-align: center!important;'>
                        <img style='float: right;' src='<?php echo base_url();?>assets/images/dashboard_logo.png' alt='logo' height='32' width='100'/>
                        
                        </div>
                    </div>
                   <div class='col-md-12 col-lg-12'>
                        <div>
                         
						 <i class='fa fa-check-circle fa-3x' aria-hidden='true' style='color:#f7e590; background-color: #cce7d4; color: #6d9648;'></i><h5>Account Activation Successful</h5>
                         <p style='font-size: 12px; font-weight: bold;'>Your account is activated. Please login here
                            Login In</p>
							<button type="button" class="btn btn-primary"><a href="https://bintexfutures.com/login">Log In</a></button>
                        </div>
                    </div>
              	</div>
		</div>-->

<html>
   
   <head>
      <title>Bintex Furtures</title>
      <link rel="stylesheet" href="https://bintexfutures.com/assets/bootstrap/css/bootstrap.min.css">
      <link rel="shortcut icon" type="image/x-icon" href="https://bintexfutures.com/assets/images/favicon.png">
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
            padding-bottom:150px;
            padding-top:150px;
         }
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         .box {
            border:#666666 solid 1px;
         }
      </style>
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div class="col-md-12 col-sm-12" style="width: 50%; text-align: center;">
            	<div style='background-color:#eeefef; padding:40px 30px;'>
            	     <div class='col-md-12'>
            	         
                        <div style='margin:0 auto; text-align: center!important;'>
                         <a href="https://bintexfutures.com">   
                        <img style='float: right;' src='<?php echo base_url();?>assets/images/dashboard_logo.png' alt='logo' height='32' width='100'/>
                        </a>
                        
                        </div>
                    </div><br>
                   <div class='col-md-12 col-lg-12'>
                        <div class="container">
                           <div class="col-md-12 col-sm-12 offset-md-1">
                            <div class="row">
                         <i class='fa fa-check-circle fa-2x' aria-hidden='true' style='color: #6d9648;'<h3>Account Activation Successful</h3></i>
						 </div>
						 </div><br>
						 
						 <div class="col-md-12 col-lg-12 offset-md-1">
						 <div class="row">
                         <h6>Your account is activated. Please login here <a href="https://bintexfutures.com/login" style="    text-decoration: none;"> Log In</a></h6>
                        </div>
                        </div>
                        
                      </div>
                    </div>
              	</div>
		</div>
			
      </div>

   </body>
</html>