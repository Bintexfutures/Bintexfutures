
<!-- START SECTION BINTEX -->
<section class="bg-color small_pt small_pb">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12 col-md-12 col-sm-12">				
	
<?php $ress=$this->db->get_where('aboutus', array('id' => '1' ))->row(); ?>

			<div class="title_default_light text-center title_border">
                <h4 class="animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.2s" style="animation-delay: 0.2s; opacity: 1;"><?php echo $ress->heading; ?></h4>
                <p class="animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.4s" style="animation-delay: 0.4s; opacity: 1; text-align: justify;"><?php echo $ress->content; ?></p>
              </div>              
            </div>
        </div>
    </div>
</section>
<!-- END SECTION BINTEX -->  


<!-- START SECTION WHITEPAPER -->
<section class="bg-color small_pt small_pb">
	<div class="container">
    	<div class="row align-items-center">
   

   <?php $down=$this->db->get_where('aboutus', array('id' => '3' ))->row(); ?>




<div class="col-lg-5">
            	<div class="text-center animation res_md_mb_30 res_sm_mb_20" data-animation="zoomIn" data-animation-delay="0.2s">
            		<img src="<?php echo base_url() ?>admin/assets/aboutpage/<?php echo $down->image; ?>" alt="whitepaper2"/>
                </div>
            </div>
            <div class="col-lg-7">
            	<div class="title_default_light">
                	<h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.3s"><?php echo $down->heading; ?></h4>
                    <p class="animation" data-animation="fadeInUp" data-animation-delay="0.5s"><?php echo $down->content; ?></p>
                </div>
                
                <?php $data12=$this->db->get_where('downloads', array('id'=>7))->row(); ?>
  <a class="btn btn-default btn-radius animation" target="_blank" href="#" data-animation="fadeInUp" data-animation-delay="1s">Download Now </a>
           
					
					
               </div>
        </div>
    </div>
</section>
<!-- END SECTION WHITEPAPER -->

<link href="<?php echo base_url() ?>css/timeTo.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="node_modules/jquery/dist/jquery.min.js"><\/script>')</script>
    <script src="<?php echo base_url() ?>css/jquery.time-to.js"></script>
    