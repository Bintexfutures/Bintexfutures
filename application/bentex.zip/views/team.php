<!-- START SECTION TEAM -->
<section class="v_blue small_pt small_pb">
    <div class="container">
        <div class="row small_space small_pt small_pb">
            
            <div class="col-lg-3 col-md-6 col-sm-6 res_md_mb_30 res_sm_mb_20">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="team_img text-center"> 
                    	<img src="assets/images/team1.jpg" alt="team1"/>
                    </div>
                    <div class="team_info text-center">
                        <h4><a href="#" class="content-popup"> Sivashankara G</a></h4>
                        <p>Founder & CEO</p>
                    </div>
                    <div id="team1" class="team_pop mfp-hide">
                        <div class="row m-0">
                            <div class="col-md-4 text-center"> 
                            	<div class="team_img_wrap">
                                    <img class="w-100" src="assets/images/team-lg-1.jpg" alt="user_img-lg"/> 
                                    <div class="team_title">
                                        <h4>Sivashankara G</h4>
                                        <span>Founder & CEO</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="pt-3">
                                    <h5>About</h5>
                                    <hr>
                                    <p>Founder of Bintex and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                    <p>Founder of Venus Media Ltd and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6 col-sm-6 res_md_mb_30 res_sm_mb_20">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="team_img text-center"> 
                    	<img src="assets/images/team2.jpg" alt="team2"/>
                    </div>
                    <div class="team_info text-center">
                        <h4><a href="#" class="content-popup">A.V.Ravitheja</a></h4>
                        <p>Founder & CEO</p>
                    </div>
                    <div id="team1" class="team_pop mfp-hide">
                        <div class="row m-0">
                            <div class="col-md-4 text-center"> 
                            	<div class="team_img_wrap">
                                    <img class="w-100" src="assets/images/team-lg-2.jpg" alt="user_img-lg"/> 
                                    <div class="team_title">
                                        <h4>A.V.Ravitheja</h4>
                                        <span>Founder & CEO</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="pt-3">
                                    <h5>About</h5>
                                    <hr>
                                    <p>Founder of Bintex and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                    <p>Founder of Venus Media Ltd and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
           <!-- <div class="col-lg-3 col-md-6 col-sm-6 res_md_mb_30 res_sm_mb_20">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="team_img text-center"> 
                    	<img src="assets/images/team1.jpg" alt="team1"/>
                    </div>
                    <div class="team_info text-center">
                        <h4><a href="#team1" class="content-popup">Shankar</a></h4>
                        <p></p>
                    </div>
                    <div id="team1" class="team_pop mfp-hide">
                        <div class="row m-0">
                            <div class="col-md-4 text-center"> 
                            	<div class="team_img_wrap">
                                    <img class="w-100" src="assets/images/team-lg-1.jpg" alt="user_img-lg"/> 
                                    <div class="team_title">
                                        <h4>Shankar</h4>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="pt-3">
                                    <h5>About</h5>
                                    <hr>
                                    <p>Founder of Bintex and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                    <p>Founder of Venus Media Ltd and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6 col-sm-6 res_md_mb_30 res_sm_mb_20">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="team_img text-center"> 
                    	<img src="assets/images/team2.jpg" alt="team2"/>
                    </div>
                    <div class="team_info text-center">
                        <h4><a href="#team2" class="content-popup">Raviteja</a></h4>
                        <p></p>
                    </div>
                    <div id="team1" class="team_pop mfp-hide">
                        <div class="row m-0">
                            <div class="col-md-4 text-center"> 
                            	<div class="team_img_wrap">
                                    <img class="w-100" src="assets/images/team-lg-2.jpg" alt="user_img-lg"/> 
                                    <div class="team_title">
                                        <h4>Raviteja</h4>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="pt-3">
                                    <h5>About</h5>
                                    <hr>
                                    <p>Founder of Bintex and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                    <p>Founder of Venus Media Ltd and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
         </div>
         <div class="divider large_divider"></div>
         <div class="row small_space small_pt small_pb">
             
            <div class="col-lg-3 col-md-6 col-sm-6 res_md_mb_30 res_sm_mb_20">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="team_img text-center"> 
                    	<img src="assets/images/team1.jpg" alt="team1"/>
                    </div>
                    <div class="team_info text-center">
                        <h4><a href="#team1" class="content-popup">Shankar</a></h4>
                        <p></p>
                    </div>
                    <div id="team1" class="team_pop mfp-hide">
                        <div class="row m-0">
                            <div class="col-md-4 text-center"> 
                            	<div class="team_img_wrap">
                                    <img class="w-100" src="assets/images/team-lg-1.jpg" alt="user_img-lg"/> 
                                    <div class="team_title">
                                        <h4>Shankar</h4>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="pt-3">
                                    <h5>About</h5>
                                    <hr>
                                    <p>Founder of Bintex and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                    <p>Founder of Venus Media Ltd and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6 col-sm-6 res_md_mb_30 res_sm_mb_20">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="team_img text-center"> 
                    	<img src="assets/images/team2.jpg" alt="team2"/>
                    </div>
                    <div class="team_info text-center">
                        <h4><a href="#team2" class="content-popup">Raviteja</a></h4>
                        <p></p>
                    </div>
                    <div id="team1" class="team_pop mfp-hide">
                        <div class="row m-0">
                            <div class="col-md-4 text-center"> 
                            	<div class="team_img_wrap">
                                    <img class="w-100" src="assets/images/team-lg-2.jpg" alt="user_img-lg"/> 
                                    <div class="team_title">
                                        <h4>Raviteja</h4>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="pt-3">
                                    <h5>About</h5>
                                    <hr>
                                    <p>Founder of Bintex and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                    <p>Founder of Venus Media Ltd and Owner of leading website for affiliates in the entertainment industry TakeBucks, he is a videographer, photographer and producer with a big number of successful entrepreneurships under his name over the last 18 years.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
            
             <div class="col-lg-6 col-md-6 col-sm-6 res_md_mb_30 res_sm_mb_20">
                <div class="title_default_light title_border">
              <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Our Team</h4>
              <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s">We are a team passionate about decentralization and better products. The current decentralized eco-system lacks usability and convenience. Decentralized transactions are slow, expensive and complex.<br>

We aim to change this by leveraging a combination of blockchain scaling, developer platform and tools, and a rabid focus on user experience. We aspire to see a world where blockchain gains mainstream adoption, and fulfills it's true promise.</p>
            </div>
            </div>
         </div>
    </div>
</section>
<!-- END SECTION TEAM -->

<link href="<?php echo base_url() ?>css/timeTo.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="node_modules/jquery/dist/jquery.min.js"><\/script>')</script>
    <script src="<?php echo base_url() ?>css/jquery.time-to.js"></script>
    <script>
        $('#clock-w-step-cb').timeTo({
          step: function() {
              console.log('Executing every 3 ticks');
          },
          stepCount: 3
        });

        var date = getRelativeDate(2);
        document.getElementById('date-str').innerHTML = date.toISOString();        /**
         * Set timer countdown to specyfied date
         */
        $('#countdown-2').timeTo(date);
        
        var time = '<?php echo $a->eventdate ; ?>';
        document.getElementById('date2-str').innerHTML = time;
        $('#countdown-3').timeTo({
            time: time,
            displayDays: 2,
            theme: "black",
            displayCaptions: true,
            fontSize: 38,
            captionSize: 14,
            lang: 'en'
        });
        $('#clock-1').timeTo();
        function getRelativeDate(days, hours, minutes) {
            var d = new Date(Date.now() + 60000 /* milisec */ * 60 /* minutes */ * 24 /* hours */ * days /* days */);
            d.setHours(hours || 0);
            d.setMinutes(minutes || 0);
            d.setSeconds(0);
            return d;
        }
    </script>