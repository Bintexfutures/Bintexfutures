
 <div class="content-wrapper">
    <div class="container-fluid">
      <div class="row upload">
        <div class="offset-md-2 col-md-8"  >
      		<div class="mb-0">
			<div class="file-header">
                <h6 class="mb-0 file">Upload Your File</h6>
            </div>
            <div class="upload d-flex justify-content-between align-items-center">
	 
	     
           <div class="col-md-6">
                <form class="row" method="post" enctype="multipart/form-data">
           <div class="form-group files" "text-center">
                <label>Upload front of Driver's License </label>
                <input type="file" class="form-control" multiple="" name="frontimage">
            </div>
             <div class="col-12">
                             <button class="btn btn-default pull-right" type="submit" name="drive1">Submit!</button>
                        </div>
            </form>
          
	   </div>
	

       
	     
                    
            </div>
            
            
	     <div class="clearfix"></div>

	<div class="col-mb-12">
	     <p>Note: *Please provide a clear, color picture of the enre
document. Screen shots are not allowed. JPG or PNG only.</p>

                        </div>
                        </div><div class="col-md-2"><a class="navbar-brand" href="index_user.php">
    	<img class="logo_icon" src="<?php echo base_url() ?>images/logo_icon.png">
        <img class="logo" src="<?php echo base_url() ?>images/logo.png">
			</a></div>
      	</div>
		</div>
      </div>
