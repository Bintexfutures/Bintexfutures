
<!-- START SECTION TIMELINE -->
<section class="bg-color small_pt small_pb">
  <div class="container">
	<div class="row text-center">
      <div class="col-lg-8 col-md-12 offset-lg-2">
        <div class="title_default_light title_border text-center">
          <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Roadmap</h4>
          <h1 class="animation" data-animation="fadeInUp" data-animation-delay="0.4s" style="font-size: 75px; color:#ffffff;">Soon We Will Announce</h1>
        </div>
      </div>
    </div>
  </div>
  
  <div class="container-fluid">
  	<div class="row">
    	<div class="col-md-12 pl-0 pr-0">
            <div class="roadmap owl-carousel small_space">
              
       <?php
    $data1=$this->db->order_by('id', 'desc')->get_where('roadmap')->result();
   
    ?>
     <?php $i=1;?>
                  <?php foreach($data1 as $h){?>
              
              <div class="item">
                <div class="roadmap_box rd_complete">
                  <div class="roadmap_inner">
                  	<div class="icon_roadmap">
                    <?php echo $h->name; ?>
                    </div>
                    <div class="roadmap_icon"></div>
                    <h6 class="animation" data-animation="fadeInUp" data-animation-delay="0.3s"><?php echo $h->cat ?></h6>
                    <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $h->description ?></p>
                  </div>
                </div>
              </div>
              
           <?php $i++;?>
                  <?php }?>    
       
              
              
            </div>
    	</div>
    </div>
  </div>
</section>
<!-- END SECTION TIMELINE -->


<link href="<?php echo base_url() ?>css/timeTo.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="node_modules/jquery/dist/jquery.min.js"><\/script>')</script>
    <script src="<?php echo base_url() ?>css/jquery.time-to.js"></script>