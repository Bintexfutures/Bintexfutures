<!-- START SECTION TEAM -->
<section class="bg-color small_pt">
    <div class="container">
         <div class="row">
          <div class="col-lg-8 col-md-12 offset-lg-2">
            <div class="title_default_light title_border text-center">
              <h5 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Latest Bintex</h5>
              <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s" style="color: #FFE991;">News</h4>
            </div>
          </div>
        </div>
        <div class="row small_space small_pt small_pb">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="text-center"> 
                    	<a href="https://youtu.be/-d-iRz0NFP4" target="_blank">
<img border="0" alt="News" src="assets/images/video1.jpg" class="responsive" /></a>
</a>
                    </div>
             </div> <h3 class="animation" data-animation="fadeInUp" data-animation-delay="1.1s" style="color:#ffffff;">Bintex Futures - Updates (1-12-2019) </h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="text-center"> 
                    	<a href="https://youtu.be/MzMrSwtdgQM" target="_blank">
<img border="0" alt="News" src="assets/images/video.jpg" class="responsive" /></a>
</a>
                    </div>
             </div> <h3 class="animation" data-animation="fadeInUp" data-animation-delay="1.1s" style="color:#ffffff;">Bintex Futures - Introduction</h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="text-center"> 
                    	<img src="assets/images/img.jpg" alt="img" class="responsive"/>
                    </div>
             </div><h3 class="animation" data-animation="fadeInUp" data-animation-delay="1.1s" style="color:#ffffff;"></h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="" data-animation="" data-animation-delay="">
                    <div class="text-center"> 
                    	<img src="assets/images/img.jpg" alt="team1" class="responsive"/>
                    </div>
             </div><h3 class="animation" data-animation="fadeInUp" data-animation-delay="1.1s" style="color:#ffffff;"></h3>
            </div>
         </div>
    </div>
</section>
<!-- END SECTION TEAM -->

<link href="<?php echo base_url() ?>css/timeTo.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="node_modules/jquery/dist/jquery.min.js"><\/script>')</script>
    <script src="<?php echo base_url() ?>css/jquery.time-to.js"></script>